 // Get all necessary elements
    const bgMusic = document.getElementById("bgMusic");
    const stepSound = document.getElementById("stepSound");
    const burnSound = document.getElementById("burnSound");
    const rustSound = document.getElementById("rustSound");
    const winSound = document.getElementById("winSound");
    const loseSound = document.getElementById("loseSound");
    const startSound = document.getElementById("startSound");

    const muteButton = document.getElementById("muteButton");
    const muteImage = document.getElementById("muteImage");
    const countdown = document.getElementById("countdown");
    const start = document.getElementById("start");

    let isMuted = false;
    let pausedTime = 0;
    let isPaused = false;

    // Mute toggle
    function toggleMute() {
      isMuted = !isMuted;
      const audios = [bgMusic, stepSound, burnSound, rustSound, winSound, loseSound, startSound];
      audios.forEach(audio => audio.muted = isMuted);
      muteImage.src = isMuted ? "mute.png" : "unmute.png";
    }
    muteButton.addEventListener("click", toggleMute);

    bgMusic.loop = true;
    bgMusic.play();

    // Countdown
    function startGame() {
      let counter = 3;
      countdown.innerText = counter;
      countdown.style.display = "block";
      const interval = setInterval(() => {
        counter--;
        if (counter === 0) {
          countdown.innerText = "GO!";
          startSound.play();
          startTimer();
        } else if (counter < 0) {
          clearInterval(interval);
          countdown.style.display = "none";
          if (!isMuted) {
            bgMusic.loop = true;
            bgMusic.play();
          }
        } else {
          countdown.innerText = counter;
        }
      }, 1000);
      if (!isMuted) startSound.play();
    }
    startGame();

    // Timer functions
    let gameStartTime;
    let timerInterval;
    function startTimer() {
      const timerDisplay = document.getElementById("timerDisplay");
      timerDisplay.style.display = "block";
      gameStartTime = Date.now() - pausedTime * 1000;
      timerInterval = setInterval(() => {
        const elapsed = Math.floor((Date.now() - gameStartTime) / 1000);
        timerDisplay.innerText = `Time: ${elapsed}s`;
      }, 1000);
    }
    function stopTimer() {
      clearInterval(timerInterval);
    }
    function pauseTimer() {
      clearInterval(timerInterval);
      pausedTime = Math.floor((Date.now() - gameStartTime) / 1000);
      isPaused = true;
    }
    function resumeTimer() {
      if (isPaused) {
        isPaused = false;
        startTimer();
      }
    }

    // Game logic
    const adventurer = document.getElementById("adventurer");
    const movingAdventurer = document.getElementById("movingAdventurer");
    const movingCharacterContainer = document.getElementById("movingCharacterContainer");
    const carriedItem = document.getElementById("carriedItem");
    const leftSide = document.getElementById("left-side");
    const rightSide = document.getElementById("right-side");
    const rightItems = document.getElementById("right-items");
    const adventurerRight = document.getElementById("adventurer-right");
    const burnedMapImage = "burnmap.gif";
    const rustedKeyImage = "rust.gif";

    let isMoving = false;
    let onRightSide = false;

    function setItemClickEvents() {
      const items = leftSide.querySelectorAll(".item");
      items.forEach(item => {
        item.addEventListener("click", () => {
          if (isMoving || onRightSide) return;
          moveWithItem(item, "right");
        });
      });
    }
    function setRightItemClickEvents() {
      const items = rightItems.querySelectorAll(".item");
      items.forEach(item => {
        item.addEventListener("click", () => {
          if (isMoving || !onRightSide) return;
          moveWithItem(item, "left");
        });
      });
    }
    setItemClickEvents();
    adventurerRight.addEventListener("click", () => {
      if (isMoving || !onRightSide) return;
      moveWithoutItem("left");
    });
    adventurer.addEventListener("click", () => {
      if (isMoving || onRightSide) return;
      moveWithoutItem("right");
    });

    function moveWithItem(item, direction) {
      isMoving = true;
      stepSound.play();
      if (direction === "right") {
        adventurer.style.display = 'none';
        movingAdventurer.src = "adv.png";
        movingCharacterContainer.style.left = '5%';
      } else {
        adventurerRight.style.display = 'none';
        movingAdventurer.src = "adv2.png";
        movingCharacterContainer.style.left = '100%';
      }
      carriedItem.src = item.src;
      carriedItem.alt = item.alt;
      carriedItem.style.display = 'block';
      movingCharacterContainer.style.display = 'block';
      setTimeout(() => {
        item.remove();
        movingCharacterContainer.style.left = (direction === "right" ? "100%" : "5%");
        setTimeout(() => {
          const dropped = document.createElement("img");
          dropped.src = carriedItem.src;
          dropped.alt = carriedItem.alt;
          dropped.className = "item";
          dropped.style.width = "60px";
          dropped.style.cursor = "pointer";
          if (direction === "right") {
            rightItems.appendChild(dropped);
            onRightSide = true;
            adventurerRight.style.display = 'block';
            setRightItemClickEvents();
          } else {
            leftSide.querySelector(".items-row").appendChild(dropped);
            onRightSide = false;
            adventurer.style.display = 'block';
            setItemClickEvents();
          }
          carriedItem.style.display = 'none';
          movingCharacterContainer.style.display = 'none';
          isMoving = false;
          checkGameState();
        }, 2000);
      }, 500);
    }
    function moveWithoutItem(direction) {
      isMoving = true;
      stepSound.play();
      if (direction === "right") {
        adventurer.style.display = 'none';
        movingAdventurer.src = "adv.png";
        movingCharacterContainer.style.left = '5%';
      } else {
        adventurerRight.style.display = 'none';
        movingAdventurer.src = "adv2.png";
        movingCharacterContainer.style.left = '100%';
      }
      movingCharacterContainer.style.display = 'block';
      setTimeout(() => {
        movingCharacterContainer.style.left = (direction === "right" ? "100%" : "5%");
        setTimeout(() => {
          movingCharacterContainer.style.display = 'none';
          if (direction === "right") {
            adventurerRight.style.display = 'block';
            onRightSide = true;
          } else {
            adventurer.style.display = 'block';
            onRightSide = false;
          }
          isMoving = false;
          checkGameState();
        }, 2000);
      }, 100);
    }

    // Rules modal pause/resume logic
    const rulesButton = document.getElementById("rulesButton");
    const rulesModal = document.getElementById("rulesModal");
    const closeRules = document.getElementById("closeRules");

    rulesButton.onclick = () => {
      rulesModal.style.display = "block";
      pauseTimer();
    };
    closeRules.onclick = () => {
      rulesModal.style.display = "none";
      resumeTimer();
    };
    window.onclick = function(event) {
      if (event.target == rulesModal) {
        rulesModal.style.display = "none";
        resumeTimer();
      }
    };

    function checkGameState() {
      const rightItemsList = [...rightItems.querySelectorAll(".item")].map(i => i.alt.toLowerCase());
      if (rightItemsList.includes("map") && rightItemsList.includes("torch") && rightItemsList.includes("key")) {
        setTimeout(() => {
          winSound.play();
          endGame("🎉 You won! All items crossed safely!");
        }, 300);
        return;
      }
      checkItemHazards();
    }
    function checkItemHazards() {
      const leftItems = [...leftSide.querySelectorAll(".item")];
      const leftAlts = leftItems.map(i => i.alt.toLowerCase());
      const isAdventurerLeftVisible = adventurer.style.display !== "none";
      if (!isAdventurerLeftVisible) {
        if (leftAlts.includes("map") && leftAlts.includes("torch")) {
          const map = leftItems.find(i => i.alt.toLowerCase() === "map");
          if (map) map.src = burnedMapImage;
          setTimeout(() => {
            burnSound.play();
            loseSound.play();
            endGameWithSadness("🔥 Map burned on LEFT side!");
          }, 300);
          return;
        }
        if (leftAlts.includes("map") && leftAlts.includes("key")) {
          const key = leftItems.find(i => i.alt.toLowerCase() === "key");
          if (key) key.src = rustedKeyImage;
          setTimeout(() => {
            rustSound.play();
            loseSound.play();
            endGameWithSadness("🧪 Key rusted on LEFT side!");
          }, 300);
          return;
        }
      }
      const rightItemsList = [...rightItems.querySelectorAll(".item")];
      const rightAlts = rightItemsList.map(i => i.alt.toLowerCase());
      const isAdventurerRightVisible = adventurerRight.style.display !== "none";
      if (!isAdventurerRightVisible) {
        if (rightAlts.includes("map") && rightAlts.includes("torch")) {
          const map = rightItemsList.find(i => i.alt.toLowerCase() === "map");
          if (map) map.src = burnedMapImage;
          setTimeout(() => {
            burnSound.play();
            loseSound.play();
            endGameWithSadness("🔥 Map burned on RIGHT side!");
          }, 300);
          return;
        }
        if (rightAlts.includes("map") && rightAlts.includes("key")) {
          const key = rightItemsList.find(i => i.alt.toLowerCase() === "key");
          if (key) key.src = rustedKeyImage;
          setTimeout(() => {
            rustSound.play();
            loseSound.play();
            endGameWithSadness("🧪 Key rusted on RIGHT side!");
          }, 300);
          return;
        }
      }
    }

    function endGameWithSadness(message) {
      stopTimer();
      bgMusic.pause();
      const modal = document.createElement("div");
      modal.style.position = "fixed";
      modal.style.top = 0;
      modal.style.left = 0;
      modal.style.width = "100%";
      modal.style.height = "100%";
      modal.style.background = "rgba(0, 0, 0, 0.85)";
      modal.style.display = "flex";
      modal.style.flexDirection = "column";
      modal.style.justifyContent = "center";
      modal.style.alignItems = "center";
      modal.style.color = "white";
      modal.style.fontSize = "30px";
      modal.style.zIndex = 1000;
      const text = document.createElement("p");
      text.innerText = message;
      modal.appendChild(text);
      const sadGif = document.createElement("img");
      sadGif.src = "sad.png";
      sadGif.alt = "Sadness";
      sadGif.style.width = "200px";
      modal.appendChild(sadGif);
      const stars = document.createElement("div");
      stars.style.margin = "20px";
      modal.appendChild(stars);
      const restartButton = document.createElement("button");
      restartButton.style.marginTop = "3px";
      restartButton.style.cursor = "pointer";
      restartButton.style.height = "50px";
      restartButton.style.width = "120px";
      restartButton.style.border = "none";
      restartButton.style.borderRadius = "12px";
      restartButton.style.backgroundImage = "url('restart.png')";
      restartButton.style.backgroundSize = "cover";
      restartButton.style.backgroundRepeat = "no-repeat";
      restartButton.style.backgroundPosition = "center";
      restartButton.onclick = () => location.reload();
      modal.appendChild(restartButton);
      document.body.appendChild(modal);
    }

    function endGame(message) {
      stopTimer();
      bgMusic.pause();
      const timeTaken = Math.floor((Date.now() - gameStartTime) / 1000);
      const modal = document.createElement("div");
      modal.style.position = "fixed";
      modal.style.top = 0;
      modal.style.left = 0;
      modal.style.width = "100%";
      modal.style.height = "100%";
      modal.style.background = "rgba(0, 0, 0, 0.85)";
      modal.style.display = "flex";
      modal.style.flexDirection = "column";
      modal.style.justifyContent = "center";
      modal.style.alignItems = "center";
      modal.style.color = "white";
      modal.style.fontSize = "30px";
      modal.style.zIndex = 1000;
      const text = document.createElement("p");
      text.innerText = message;
      modal.appendChild(text);
      const stars = document.createElement("div");
      stars.style.margin = "20px";
      let starCount = 5;
      if (timeTaken > 60) starCount = 3;
      else if (timeTaken > 30) starCount = 4;
      for (let i = 0; i < starCount; i++) {
        const starImg = document.createElement("img");
        starImg.src = "star.gif";
        starImg.alt = "Star";
        starImg.style.width = "50px";
        starImg.style.height = "50px";
        starImg.style.margin = "0 5px";
        stars.appendChild(starImg);
      }
      modal.appendChild(stars);
      const hGif = document.createElement("img");
      hGif.src = "happy.png";
      hGif.alt = "happy";
      hGif.style.width = "140px";
      modal.appendChild(hGif);
      const restartButton = document.createElement("button");
      restartButton.style.marginTop = "90px";
      restartButton.style.cursor = "pointer";
      restartButton.style.height = "50px";
      restartButton.style.width = "120px";
    }